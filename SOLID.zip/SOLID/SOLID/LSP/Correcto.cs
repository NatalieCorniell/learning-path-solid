﻿using System;
namespace SOLID.LSP
{
    public class Correcto
    {
        //Natalie's Code
        class Libros
        {
            public int Estrellas { get; set; }
        }

        class Comedia : Libros
        {
            public string ObtenerCategoria()
            {
                return "";
            }
        }

        class Romance : Libros
        {
            public string Obtenerlibro()
            {
                return "";
            }
        }

        class Impuestos
        {
            public void CalcularPopularidad(Libros Libros, string estrellas)
            {
                string libro = string.Empty;
                if (Libros.GetType().Name == "Romance")
                    libro = ((Romance)Libros).Obtenerlibro();
                else if (Libros.GetType().Name == "Comedia")
                    libro = ((Comedia)Libros).ObtenerCategoria();
                ServicioCalculoImpuestos(libro, estrellas);
            }

            private void ServicioCalculoImpuestos(string libro, string estrellas)
            {
                throw new NotImplementedException();
            }
        }
    }
}
