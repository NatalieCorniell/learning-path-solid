﻿using System;
namespace SOLID.LSP
{
    public class Incorrecto
    {
        //Natalie's Code
        class Libros
        {
            public int Estrellas { get; set; }
        }

        class Comedia : Libros
        {
            public string ObtenerCategoria()
            {
                return "";
            }
        }

        class Romance : Libros
        {
            public string Obtenerlibro()
            {
                return "";
            }
        }

        class Impuestos
        {
            public void CalcularPopularidad(Libros Libros)
            {
                string libro = ((Romance)Libros).Obtenerlibro();
                ServicioCalculoImpuestos(libro, Libros.Estrellas);
            }

            private void ServicioCalculoImpuestos(string libro, int estrellas)
            {
                throw new NotImplementedException();
            }
        }
    }
}
