﻿using System;

namespace SOLID
{
    public class Correcto
    {
        //Natalie's Code
        public string nombreAlumno = "Naty";
        public double notaAlumno = 90;
        public Correcto()
        {
            ValidarAlumno(nombreAlumno, notaAlumno);
        }

        private void MostrarNotaFinal(double nota)
        {
            if (nota >= 75)
            {
                Console.WriteLine("Felicitaciones!" +
                    "Tu nota Final de programación es: " + nota);
            }
            else
            {
                Console.WriteLine("Sera la próxima :(" +
                 "Tu nota Final de programación es: " + nota);
            }
        }
        private void ValidarAlumno(string nombreAlumno, double notaAlumno)
        {
            if (nombreAlumno == "Naty")
            {
                MostrarNotaFinal(notaAlumno);
            }
        }
    }
}
