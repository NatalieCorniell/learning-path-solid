﻿using System;
namespace SOLID.SRP
{
    public class Incorrecto
    {
        //Natalie's Code
        public string nombreAlumno = "Naty";
        public double notaAlumno = 90;
        public Incorrecto(){
            MostrarNotaFinal(nombreAlumno, notaAlumno);
         }
        private void MostrarNotaFinal(string nombreAlumno, double notaAlumno)
        {
            if (nombreAlumno == "Naty")
            {
                if (notaAlumno >= 75)
                {
                    Console.WriteLine("Felicitaciones!" +
                        "Tu nota Final de programación es: " + notaAlumno);
                }
                else
                {
                    Console.WriteLine("Sera la próxima :(" +
                     "Tu nota Final de programación es: " + notaAlumno);
                }
            }
           
        }
    }
}
