﻿using System;
namespace SOLID.DIP
{
    public class CuerpoRobot
    {
        public void Caminar() { }
        public void Volar() { }
        public void Disparar() { }
    }
    public class Robot
    {
        public CuerpoRobot Cuerpo { get; set; }
        public Robot() { }

        public void Caminar()
        {
            if (Cuerpo != null)
                Cuerpo.Caminar();
        }

        public void Volar()
        {
            if (Cuerpo != null)
                Cuerpo.Volar();
        }

        public void Disparar()
        {
            if (Cuerpo != null)
                Cuerpo.Disparar();
        }
    }
}
