﻿using System;
namespace SOLID.DIP
{
    public class Incorrecto
    {
        class RobotInicial
        {
            public RobotInicial() { }
            public void Caminar() { }
            public void Disparar() { }
            public void Volar() { }
        }
    }
}
