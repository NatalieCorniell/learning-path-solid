﻿using System;
namespace SOLID.ISP
{

    //natalie's Code
    interface IAnimal
    {
        void Comer();
        void Volar();
        void Dormir();
        void Nadar();
    }

    class Perro :  IAnimal
    {
        public void Comer()
        {
            //
        }
        public void Dormir()
        {
            //
        }
        public void Nadar()
        {
            //
        }
        public void Volar()
        {
            //
        }
    }

    class Pulpo : IAnimal
    {
        public void Comer()
        {
            //
        }
        public void Dormir()
        {
            //
        }
        public void Nadar()
        {
            //
        }
        public void Volar()
        {
          //
        }
    }
}
