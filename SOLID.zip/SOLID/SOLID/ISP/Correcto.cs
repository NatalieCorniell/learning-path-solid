﻿using System;
namespace SOLID.ISP
{
    //natalie's Code
    interface IAnimalMarino
    {
        void Comer();
    }
    interface IAnimalTerrestre
    {
        void Volar();
    }
    interface IAnimal
    {
        void Dormir();
    }

    interface IAveNadadora
    {
        void Nadar();
    }

    class Perro : IAnimalTerrestre, IAnimal
    {
        public void Comer()
        {
          //
        }

        public void Dormir()
        {
            //
        }

        public void Volar()
        {
            //
        }
    }

    class Pulpo : IAnimal, IAnimalMarino{
        public void Comer()
        {
            //
        }

        public void Dormir()
        {
            //
        }

        public void Nadar()
        {
           //
        }

    }
}                   
