﻿using System;
using System.Collections.Generic;

namespace SOLID.OCP
{
    public class Incorrecto
    {
        //Natalie's Code
        public List<string> Peliculas = new List<string>();

        public Incorrecto()
        {
            Guardar();
            EditarPelicula();
        }
        private void Guardar()
        {
            Peliculas.Add("Armagen");
        }
        private void EditarPelicula()
        {
            Peliculas[203] = "Armagedón";
            Console.Write("Pelicula: " +
                Peliculas[203].ToString() + "Actulizada!");
        }
    }
}
