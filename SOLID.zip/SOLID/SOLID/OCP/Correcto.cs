﻿using System;
using System.Collections.Generic;

namespace SOLID.OCP
{
    public class Correcto
    {
        //Natalie's Code
        public List<string> Peliculas = new List<string>();
        public string Pelicula { get; set; }
        public int Code { get; set; }

        public Correcto()
        {
            Guardar(Pelicula);
            EditarPelicula(Code, Pelicula);
        }
        private void Guardar (string pelicula)
        {
           Peliculas.Add(pelicula);
        }
        private void EditarPelicula(int code, string newNamePeli)
        {
            Peliculas[code] = newNamePeli;
            Console.Write("Pelicula: " +
                Peliculas[code].ToString() + "Actulizada!");
        }

    }
}
